#include "Conversion.h"                    //**▲03 栈和队列**//

int main(int argc, char** argv) {
    int i = 342391;
    
    printf("将十进制数转换为八进制数...\n");
    
    conversion(i);
    
    return 0;
}
